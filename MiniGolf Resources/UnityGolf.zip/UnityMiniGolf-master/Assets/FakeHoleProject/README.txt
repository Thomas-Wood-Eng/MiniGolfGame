My tutorial on making fake holes: https://www.youtube.com/watch?v=cHhxs12ZfSQ

Golf Ball bump map: http://forums.cgsociety.org/t/golf-ball/699835/7

Grass: https://www.textures.com/download/grass0133/41195
